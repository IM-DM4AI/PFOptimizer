import torch
import torch.nn as nn

print(a)

print(__name__)

class SimpleLinearModel(nn.Module):
    def __init__(self):
        super(SimpleLinearModel, self).__init__()
        self.linear = nn.Linear(1, 1)
    def forward(self, x):
        return self.linear(x)


model_path7 = f'/home/admin0/PFRewriter/dynamic_cacher/models/torch_full_model.pth'
torch_model = torch.load(model_path7)